import { getAllHeroes, addHero, deleteHero, getHero } from "@/actions/heroactions"

export default async function Home() {
  const Hero = await getAllHeroes();
  return <div>
           <h2 className="text-center" >Server Actions</h2>
          <form action={addHero}>
          <input className="outline-1 p-5 block" type="text" name="name" />
          <input className="outline-1 p-5 block" type="text" name="era" />
          <input className="outline-1 p-5 block" type="text" name="region" />
          <button className="bg-amber-800 text-amber-50 font-serif" type="submit">Add Hero</button>
          </form>
           <hr />
           <ol className="text-center">
            { Hero.map(val => <li key={val._id+""}>{val.name}  
              <form action={deleteHero.bind(null, val._id+"")}>
              <button className="text-red-500 hover:text-red-700 font-bold">Delete</button>
              </form>
        </li>)}
           </ol>
         </div>
}
