import mongoose, {Schema, Document, Model } from "mongoose";

// Document
export interface IHero extends Document{
    name : string;
    era : string;
    region : string
}

const HeroSchema:Schema = new Schema({
    name : { type : String, require : true },
    era : { type : String, require : true },
    region : { type : String, require : true },
})

// const Hero = mongoose.model('Hero', HeroSchema);
// Prevent model overwrite error in development
const Hero: Model<IHero> = mongoose.models.Hero || mongoose.model<IHero>('Hero', HeroSchema);

export default Hero;