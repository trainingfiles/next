// step 1
import mongoose from "mongoose";

const MONGODB_URL = process.env.MONGODB_URL;

let mongodb = ( global as any ).mongoose;

/* 
mongoose.connect will give us a promise back 
which we shall call as connected to denote 
that we are connected
*/
if(!mongodb){
    mongodb = ( global as any ).mongoose = { connected: null, promise: null };
}

async function connectDB(){
    if(mongodb.connected) return mongodb.connected;
    if(!mongodb.promise){
        mongodb.promise = mongoose.connect(MONGODB_URL+"")
        .then(mongoose => {
            return mongoose
        });
    }
    mongodb.connected = await mongodb.promise;
    return mongodb.connected
}

export default connectDB;