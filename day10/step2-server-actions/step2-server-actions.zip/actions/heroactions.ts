"use server"

import connectDB from "@/connections/db";
import Hero from "@/models/hero";
import { revalidatePath } from "next/cache";

/* 
getAllHeroes
addHero
 -- > this can be done by adding another page
 - > getSelectedHero
 - >  updateHero
deleteHero
*/
export async function getAllHeroes(){
    await connectDB();
    const hero = await Hero.find({}).sort({ name : 1 }).lean();
    return hero
}
export async function deleteHero(id: string){
        await connectDB();
        await Hero.findByIdAndDelete(id);
        revalidatePath('/');
}

export async function addHero(formData:FormData){
   await connectDB();
   const name = formData.get("name");
   const era = formData.get("era");
   const region = formData.get("region");
   await Hero.create({name, era, region});
   revalidatePath('/');
}

