import mongoose from "mongoose";

// Model
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;
const Hero = mongoose.model("Hero",new Schema({
    id : ObjectId,
    name : String,
    era : String,
    region : String
}));

export { Hero }