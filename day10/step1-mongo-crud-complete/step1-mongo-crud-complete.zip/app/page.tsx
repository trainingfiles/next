'use client'

import { useEffect, useState } from "react"

interface IHero{
  _id : string
  name : string
  era : string
  region : string
}

export default function Home() {
  const [heroes, setHeroes] = useState([]);
  const [showEdit, setShowEdit] = useState(false);
  const [heroToEdit, setheroToEdit] = useState({
    _id : "",
    name : "",
    era : "",
    region : ""
  });
  const [newHero, setNewHero] = useState({
    name : "",
    era : "",
    region : ""
  });
  const reload = () => {
    fetch("http://localhost:3000/api/heroes")
    .then(res => res.json())
    .then(herores => setHeroes(herores) )
  }
  useEffect(()=>{
    reload();
  },[]);
  //----------------------------------
  const changeHandler = (evt)=>{
    setNewHero({...newHero, [evt.target.id] : evt.target.value })
  }
  //----------------------------------
  const editHandler = function(evt){
    // console.log(evt.target.getAttribute("data-valtech"))
    // console.log(evt.target.name);
    fetch("http://localhost:3000/api/heroes/"+evt.target.name)
    .then(res => res.json())
    .then(actualresult =>  {
      setheroToEdit(actualresult)
      setShowEdit(!showEdit);
    })
    .catch(error => console.log("Error",error))
  }
  const deleteHandler = function(evt){
    // console.log(evt.target.name)
    fetch("http://localhost:3000/api/heroes/"+evt.target.name, {
      method : "DELETE"
    }).then(res => reload()).catch(err => console.log("Error", err))
  }
  //----------------------------------
  const updateHeroInfo = () => {
     fetch("http://localhost:3000/api/heroes/"+heroToEdit._id,{
      method : "PATCH",
      body : JSON.stringify(heroToEdit),
    }).then(res =>  {
      reload();
      setShowEdit(!showEdit);
    })
  }
  //----------------------------------
  const updateHandler = (evt) => {
    setheroToEdit({...heroToEdit, [evt.target.id] : evt.target.value });
  }
  //----------------------------------
  const addNewHero = () => {
    fetch("http://localhost:3000/api/heroes",{
      method : "POST",
      body : JSON.stringify(newHero),
    }).then(res => {
      reload();
      setNewHero({
        name : "",
        era : "",
        region : ""
      })
    })
  }
  return <div>
    <h2 className="text-center text-4xl">MongoDB CRUD</h2>
   { !showEdit && <fieldset className="fieldset m-auto w-80">
      <legend className="fieldset-legend">Add Hero</legend>
      <label htmlFor="name">Hero Name</label>
      <input id="name" type="text" onChange={changeHandler} className="input" value={newHero.name} placeholder="Hero Name" />
      <br />
      <label htmlFor="era">Hero Era</label>
      <input id="era" type="text" onChange={changeHandler} className="input" value={newHero.era} placeholder="Hero Era" />
      <br />
      <label htmlFor="region">Hero Region</label>
      <input id="region" type="text" onChange={changeHandler} className="input" value={newHero.region} placeholder="Hero Region" />
      <button onClick={ addNewHero } className="btn btn-primary">Add Hero</button>
    </fieldset>}

    {showEdit && <fieldset className="fieldset m-auto w-80">
      <legend className="fieldset-legend">Edit Hero</legend>
      <label htmlFor="name">Edit Hero Name</label>
      <input id="name" type="text" onChange={updateHandler} className="input" value={heroToEdit.name} placeholder="Hero Name" />
      <br />
      <label htmlFor="era">Edit Hero Era</label>
      <input id="era" type="text" onChange={updateHandler} className="input" value={heroToEdit.era} placeholder="Hero Era" />
      <br />
      <label htmlFor="region">Edit Hero Region</label>
      <input id="region" type="text" onChange={updateHandler} className="input" value={heroToEdit.region} placeholder="Hero Region" />
      <button onClick={ updateHeroInfo } className="btn btn-primary">Update Hero</button>
    </fieldset>}
{/*     <pre>{JSON.stringify(heroToEdit)}</pre> */}
    <table className="table w-200 m-auto">
      <thead>
        <tr>
          <th>Sl #</th>
          <th>Name </th>
          <th>Era </th>
          <th>Region</th>
          <th>Edit</th>
          <th>Delete</th>
        </tr>
      </thead>
      <tbody>
        { heroes.map((val:IHero, idx) => <tr key={val._id}>
            <td>{idx+1}</td>
            <td>{ val.name }</td>
            <td>{ val.era }</td>
            <td>{ val.region }</td>
            <td>
              <button name={val._id} onClick={editHandler} className="btn btn-soft btn-primary">Edit</button>
            </td>
            <td>
              <button name={val._id} onClick={deleteHandler} className="btn btn-soft btn-secondary">Delete</button>
            </td>
        </tr>
      )}
      </tbody>
    </table>
  </div>
}
