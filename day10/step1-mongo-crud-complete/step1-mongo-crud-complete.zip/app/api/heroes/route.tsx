import { Hero } from "@/models/hero";
import { connect } from "@/connections/connection";
import { NextRequest, NextResponse } from "next/server";


export async function GET(request:NextRequest){
    connect();
    let heroeslist ; 
    await Hero.find().then(dbres => {
        heroeslist = dbres;
    } );
    return await NextResponse.json(heroeslist)
}

export async function POST(request:NextRequest){
   connect();
   const newHero = await request.json()
   const hero = await new Hero({
       name : newHero.name,
       era : newHero.era,
       region : newHero.region
   });
   hero.save().then(dbres => console.log(dbres.name, "was added in to database"))
   .catch(err => console.log("Error", err));
   
   return NextResponse.json("post was called")
}