import { Hero } from "@/models/hero";
import { connect } from "@/connections/connection";
import { NextRequest, NextResponse } from "next/server";


export async function GET(request:NextRequest, { params } : { params : Promise<{ id:string }>}){
    const hid = (await params).id;
    let heroToEdit;
    connect();
    await Hero.findById(hid)
    .then(dbres => heroToEdit = dbres)
    .catch(error => console.log("Error", error))
    //     console.log(hid);
    return NextResponse.json(heroToEdit)
}
//===========
export async function PATCH(request:NextRequest, { params } : { params : Promise<{ id:string }>}){
   connect();
   const heroid = (await params).id;
   const newHeroInfo = await request.json();
   let inforAfterUpdate;
   await Hero.findByIdAndUpdate(heroid,newHeroInfo)
   .then(dbres => inforAfterUpdate = dbres)
   return NextResponse.json(inforAfterUpdate)
}
//===========
export async function DELETE(request:NextRequest, { params } : { params : Promise<{ id:string }>}) {
    const heroid = (await params).id;
    let deletedHero ;
    connect();
    await Hero.findByIdAndDelete(heroid)
    .then( dbres => deletedHero = dbres )
    .catch( err => console.log("Error", err))
    return NextResponse.json(deletedHero)
}