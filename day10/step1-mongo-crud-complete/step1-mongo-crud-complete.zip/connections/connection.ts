import mongoose from "mongoose";

// Connection Settings
export const connect = function(){
    mongoose.connect(process.env.MONGODB_URL+"")
    .then(res => console.log("DB Connected"))
    .catch(err => console.log("Error", err));
}
