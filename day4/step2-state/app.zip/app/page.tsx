"use client";
import React, { useRef, useState } from "react";
export default function Home(){
  // const message:string = "welcome to Next Training";
  // const avengers:string[] = ["Ironman","Thor","Hulk","Spiderman"];
  // console.log(useState());
  // state 
  const [state, setState] = useState("welcome to next training !!!");
  const [avengers, setAvengers] = useState(["Ironman","Thor","Hulk","Spiderman"]);
  const [power, setPower] = useState(0);
  const [batman, setBatman] = useState({firstname:"Bruce", lastname:"Wayne"});

  // const powerip = React.createRef();
  const powerip = useRef(0);
  return <div>
          <h1>Component State</h1>
          <h2>{ state }</h2>
          <button onClick={()=> setState("title changed")}>Change Message</button>
          <hr />
          <h2>{avengers[0]}</h2>
          <h2>{avengers[1]}</h2>
          <h2>{avengers[2]}</h2>
          {/* <button onClick={ ()=> {
            avengers.push("new Hero");
            console.log(avengers);
          } }>Add Avenger</button> */}
          <button onClick={ ()=> {
            setAvengers([...avengers,"new hero"]);
            console.log(avengers);
          } }>Add Avenger</button>
          <ol>
            {avengers.map((val, idx)=> <li key={idx}>{val}</li>)}
          </ol>
          <h3>Power is {power}</h3>
          <button onClick={ ()=> setPower(power+1) }>Add Power</button>
          <button onClick={ ()=> setPower(power-1) }>Remove Power</button>
          <input defaultValue={ power } type="range" min={0} max={10} />
          <br />
          <input value={ power } onChange={(evt)=>setPower(Number(evt.target.value))} type="range" />
          <br />
          <input ref={powerip} defaultValue={power} type="number" />
          <button onClick={()=> setPower(powerip.current.value)}>Set Power</button>
          <br />
          <br />
          <h3>First Name : {batman.firstname}</h3>
          <h3>Last Name : {batman.lastname}</h3>
          <br />
          <label htmlFor="fname">First Name</label>
          <input id="fname" type="text" onChange={(evt)=> setBatman({...batman,'firstname':evt.target.value})} value={batman.firstname} />
          <br />
          <label htmlFor="lname">Last Name</label>
          <input id="lname" type="text" onChange={(evt)=> setBatman({...batman,'lastname':evt.target.value})} value={batman.lastname} />
          <br />
          <br />
        </div>
}