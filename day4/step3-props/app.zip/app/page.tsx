"use client";

import { useState } from "react";
import ChildComp from "./components/child";
import HeroComp from "./components/hero";

export default function Home(){
  let [power, setPower] = useState(0);
  let [info, setInfo] = useState({
    titles : ["Avengers", "Justice League", "Indic Hereos"],
    avengers : ["ironman","hulk","thor"],
    justiceLeague : ["batman","wonder women","flash"],
    indicHeroes : ["shaktiman","chota bheem","mighty raju"],
  })
  return <div>
          <h1>Props in NextJS</h1>
          <input type="range" min={0} max={10} step={1} onChange={(evt)=>setPower(Number(evt.target.value))} />
          <ChildComp title="First Child Component"> 
            <h3>Power is :  { power }</h3>
           <br />
            <button>Click Me</button>
            <div>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem repudiandae dolores consectetur iusto maxime quae enim vel molestiae ipsum aut atque hic id tenetur, ducimus minus deserunt veniam illum quam.
            </div>
          </ChildComp>
          <ChildComp title="Second Child Component"> 
            <h3>Power is :  { power }</h3>
           <br />
            <button>Click Me</button>
            <div>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem repudiandae dolores consectetur iusto maxime quae enim vel molestiae ipsum aut atque hic id tenetur, ducimus minus deserunt veniam illum quam.
            </div>
          </ChildComp>
          <hr />
          <HeroComp title={info.titles[0]} list={info.avengers}/>
          <HeroComp title={info.titles[1]} list={info.justiceLeague}/>
          <HeroComp title={info.titles[2]} list={info.indicHeroes}/>
        </div>
}