interface Props{
    title : string,
    list : string[]
};
export default function HeroComp(props:Props){
    return <div>
                <h1>{ props.title }</h1>
                <ol>{ props.list.map(( val, idx ) => <li key={idx}>{ val }</li> )}</ol>
            </div>
}