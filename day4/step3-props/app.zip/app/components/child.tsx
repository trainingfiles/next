export default function ChildComp(props){
    return <div>
                <h2>{props.title}</h2>
                <hr />
                <div style={ {backgroundColor : "slategray", padding : "10px" , border : "1px solid grey"} }>
                    {props.children}
                </div>
            </div>
}