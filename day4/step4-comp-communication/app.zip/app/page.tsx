'use client';

import { useRef, useState } from "react";
import ChildComp from "./components/childcomp/childcomp";

export default function Home(){
  const [value, setValue ] = useState("empty");
  const txtip = useRef("");
  return <div>
          <h1>Component Communication</h1>
          <fieldset>
            <legend>Send Message</legend>
            <h3>Parent's Value : { value }</h3>
            <hr />
            <label htmlFor="txtip">Message : </label>
            <input ref={txtip} id="txtip" type="text" />
            <button onClick={()=>setValue(txtip.current.value)}>Send</button>
          </fieldset>
          <ChildComp setMyValue={setValue} value={value}/>
         </div>
}