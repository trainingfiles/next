export default function Home() {
  return <div className="w-400 bg-emerald-200 h-25">
            <h2>Contact Page</h2>
          </div>
}
