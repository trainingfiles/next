export default function UserArticleComp() {
  return <div className="w-500 bg-amber-300 h-30">
            <h2>User Article Page</h2>
         </div>
}
