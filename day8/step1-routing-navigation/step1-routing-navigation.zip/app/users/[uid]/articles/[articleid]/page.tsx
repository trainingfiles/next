export default async function ArticleAndUserId({ params } : { params : Promise<{
  uid : string,
  articleid : string
}>}){
  // const args = (await params);
  const uid = (await params).uid;
  const articleid = (await params).articleid;
  return <div className="w-500 bg-amber-800 text-amber-50 h-30">
            <h2>User Article Number Page</h2>
            <h3>User # {uid}</h3>
            <h3>Article # {articleid}</h3>
         </div>
}