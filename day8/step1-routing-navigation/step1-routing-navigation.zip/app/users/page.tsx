export default function UserMainComp() {
  return <div className="w-500 bg-red-300 h-30">
            <h2>User Main Page</h2>
         </div>
}
