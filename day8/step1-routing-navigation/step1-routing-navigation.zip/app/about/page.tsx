export default function About(){
    return <div className="w-400 bg-blue-200 h-25">
            <h2>About Page</h2>
           </div>
}