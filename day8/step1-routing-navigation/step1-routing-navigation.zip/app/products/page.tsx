export default function Product() {
  return <div className="w-400 bg-lime-300 h-25">
            <h2>Products Page</h2>
         </div>
}
