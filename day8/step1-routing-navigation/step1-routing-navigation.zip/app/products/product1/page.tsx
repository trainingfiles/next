export default function Product1() {
  return <div className="w-400 bg-lime-100 h-25">
            <h2>Product One Page</h2>
         </div>
}
