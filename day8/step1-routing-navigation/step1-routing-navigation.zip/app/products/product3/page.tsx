export default function Product3() {
  return <div className="w-400 bg-lime-700 h-25">
            <h2>Product Three Page</h2>
         </div>
}
