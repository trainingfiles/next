export default function Product2() {
  return <div className="w-400 bg-lime-500 h-25">
            <h2>Product Two Page</h2>
         </div>
}
