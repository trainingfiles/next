export default function LibComp() {
  return <div className="w-400 bg-orange-900 h-25 text-amber-50">
            <h2>Lib Page</h2>
         </div>
}
