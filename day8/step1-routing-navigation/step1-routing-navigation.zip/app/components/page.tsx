export default function ChildComp() {
  return <div className="w-400 bg-orange-200 h-25">
            <h2>Child Page</h2>
          </div>
}
