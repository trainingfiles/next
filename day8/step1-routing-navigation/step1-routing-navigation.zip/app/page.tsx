export default function Home() {
  return <div className="w-400 bg-orange-200 h-25">
            <h2>Home Page</h2>
          </div>
}
