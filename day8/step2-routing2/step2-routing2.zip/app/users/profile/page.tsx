export default function UserProfile() {
  return <div className="w-400 bg-gray-400 h-25">
            User Profile Page
          </div>
}
