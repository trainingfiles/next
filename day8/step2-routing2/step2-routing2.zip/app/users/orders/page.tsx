export default function UserOrders() {
  return <div className="w-400 bg-gray-600 text-gray-100 h-25">
            User Order Page
          </div>
}
