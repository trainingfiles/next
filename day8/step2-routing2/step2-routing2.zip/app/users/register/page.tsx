export default function UserRegister() {
  return <div className="w-400 bg-gray-200 h-25">
            User Register Page
          </div>
}
