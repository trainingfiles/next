export default function HeroPoster() {
  return <div className="w-400 bg-blue-300 h-25">
            Hero Poster Page
          </div>
}
