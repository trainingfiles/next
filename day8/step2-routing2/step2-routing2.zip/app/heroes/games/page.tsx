export default function HeroGames() {
  return <div className="w-400 bg-blue-600 h-25">
            Hero Games Page
          </div>
}
