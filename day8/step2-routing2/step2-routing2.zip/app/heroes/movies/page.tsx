export default function HeroMovies() {
  return <div className="w-400 bg-blue-500 h-25">
            Hero Movies Page
          </div>
}
