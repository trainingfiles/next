export default function Home() {
  return <div className="w-400 bg-gray-500 h-25">
            App Home page
          </div>
}
