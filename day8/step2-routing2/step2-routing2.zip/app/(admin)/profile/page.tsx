export default function AdminProfile() {
  return <div className="w-400 bg-amber-500 h-25">
            Admin Profile Page
          </div>
}
