export default function AdminDashboard() {
  return <div className="w-400 bg-amber-300 h-25">
            Admin Dashboard Page
          </div>
}
