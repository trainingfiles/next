import Image from "next/image";

interface IHero{
    id : number;
    name: string;
    era: string;
    region: string;
    known_for: string[];
    weapons: string[];
    photo: string;
};

export default async function Home() {
    const raw = await fetch(process.env.URL+"/api/heroes");
    const data = await raw.json();
  return <div>
          <h2>API Calls in NextJS</h2>
          {/* <ol>{ data.heroes.map((val:IHero) => <li key={val.id}>{val.name}</li>) }</ol>  */}
          <div className="m-auto overflow-x-auto rounded-box border border-base-content/5 bg-base-100 w-250">
  <table className="table">
        <thead>
          <tr>
            <th>Sl #</th>
            <th>Poster</th>
            <th>Name</th>
            <th>Era</th>
            <th>Region</th>
            <th>Weapons</th>
            <th>Known For</th>
          </tr>
        </thead>
        <tbody>
          {data.heroes.map(val => <tr key={val.id}>
            <th>{val.id}</th>
            <td>
              <Image alt="warrior" width={150} height={100} src={"/"+val.photo} />
              {/* alt width height src */}
            </td>
            <td>{ val.name }</td>
            <td>{ val.era }</td>
            <td>{ val.region }</td>
            <td>{ val.weapons.length }</td>
            <td>{ val.known_for.length }</td>
          </tr>)}
        </tbody>
  </table>
  <hr />
  <form action={process.env.URL+'/api/heroes'} method="post">
    <label htmlFor="uname">User Name</label>
    <input name="username" id="uname" type="text" />
    <button>Submit</button>
  </form>
    </div>
        </div>
}
