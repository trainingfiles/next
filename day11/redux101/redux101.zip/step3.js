import { legacy_createStore } from "redux";
const createStore = legacy_createStore;


const ADD_HERO = "ADD_HERO";
const REMOVE_HERO = "REMOVE_HERO";
const SET_HERO = "SET_HERO";

const addHero = function(){
    return {
                type : ADD_HERO
            }; 
}
const removeHero = function(){
    return {
                type : REMOVE_HERO,
            }; 
}
const setHero = function(){
    return {
                type : SET_HERO,
                payload : count
            }; 
}

const initialState = {
    herocount : 0
}

function reducer(state = initialState, action){
    switch(action.type){
        case ADD_HERO : return { herocount : state.herocount+1 }
        case REMOVE_HERO : return { herocount : state.herocount-1 }
        case SET_HERO : return { herocount :  action.payload }
        default : return state
    };
};

const store = createStore(reducer);

console.log(store.getState());

let unsubscribe = store.subscribe(()=>{
    console.log("upon change of the state",store.getState());
});

store.dispatch(addHero());// 1
store.dispatch(addHero());// 2
store.dispatch(addHero());// 3
store.dispatch(addHero());// 4
store.dispatch(removeHero());// 3
