import { legacy_createStore } from "redux";
const createStore = legacy_createStore;
/* 
type
action
reducer
initialState
store

hero app where we increase / decrease / set number of heroes 

*/

// type
const INCREASE_HERO = "INCREASE_HERO";

// action 
/* 
const addHero = {
    type : INCREASE_HERO,
    payload : 6
}; 
*/

// actionCreator
const addHero = function(count){
    return {
                type : INCREASE_HERO,
                payload : count
            }; 
}

const initialState = {
    herocount : 0
}

// reducer - pure functioncls
function reducer(state = initialState, action){
    switch(action.type){
        case INCREASE_HERO : return { herocount :  action.payload }
        default : return state
    };
};

const store = createStore(reducer);

console.log(store.getState());

let unsubscribe = store.subscribe(()=>{
    console.log("upon change of the state",store.getState());
});

store.dispatch(addHero(1));
store.dispatch(addHero(2));
store.dispatch(addHero(3));
unsubscribe();
store.dispatch(addHero(4));
store.dispatch(addHero(5));
store.dispatch(addHero(6));
console.log(store.getState());