import { legacy_createStore, combineReducers, applyMiddleware } from "redux";
import reduxlogger from 'redux-logger';

const createStore = legacy_createStore;
const { createLogger } = reduxlogger;
const logger = createLogger();
// HERO STATE
const ADD_HERO = "ADD_HERO";
const REMOVE_HERO = "REMOVE_HERO";
const SET_HERO = "SET_HERO";

// MOVIE STATE
const ADD_MOVIE = "ADD_MOVIE";
const REMOVE_MOVIE = "REMOVE_MOVIE";
const SET_MOVIE = "SET_MOVIE";

// GAME STATE
const ADD_GAME = "ADD_GAME";
const REMOVE_GAME = "REMOVE_GAME";
const SET_GAME = "SET_GAME";

const addHero = function(){
    return {
                type : ADD_HERO
            }; 
}
const removeHero = function(){
    return {
                type : REMOVE_HERO,
            }; 
}
const setHero = function(count){
    return {
                type : SET_HERO,
                payload : count
            }; 
}
//----------------------------------
const addGame = function(){
    return {
                type : ADD_GAME
            }; 
}
const removeGame = function(){
    return {
                type : REMOVE_GAME,
            }; 
}
const setGame = function(count){
    return {
                type : SET_GAME,
                payload : count
            }; 
}
//-----------------------------------
const addMovie = function(){
    return {
                type : ADD_MOVIE
            }; 
}
const removeMovie = function(){
    return {
                type : REMOVE_MOVIE,
            }; 
}
const setMovie = function(count){
    return {
                type : SET_MOVIE,
                payload : count
            }; 
}

const initialHeroState = {
    herocount : 0
}
const initialMovieState = {
    moviecount : 10
}
const initialGameState = {
    gamecount : 20
}

function heroReducer(state = initialHeroState, action){
    switch(action.type){
        case ADD_HERO : return { herocount : state.herocount+1 }
        case REMOVE_HERO : return {herocount : state.herocount-1 }
        case SET_HERO : return { herocount :  action.payload }
        default : return state
    };
};

function movieReducer(state = initialMovieState, action){
    switch(action.type){
        case ADD_MOVIE : return { moviecount : state.moviecount+1 }
        case REMOVE_MOVIE : return { moviecount : state.moviecount-1 }
        case SET_MOVIE : return { moviecount :  action.payload }
        default : return state
    };
};

function gameReducer(state = initialGameState, action){
    switch(action.type){
        case ADD_GAME : return { gamecount : state.gamecount+1 }
        case REMOVE_GAME : return { gamecount : state.gamecount-1 }
        case SET_GAME : return { gamecount :  action.payload }
        default : return state
    };
};

const store = createStore(combineReducers({
    hero : heroReducer,
    movie : movieReducer,
    game : gameReducer
}),applyMiddleware(logger));

console.log(store.getState());

let unsubscribe = store.subscribe(()=>{ });

store.dispatch(addHero());// 1
store.dispatch(addHero());// 2
store.dispatch(addHero());// 3
store.dispatch(addHero());// 4
store.dispatch(setHero(10));// 14
store.dispatch(removeHero());// 13

store.dispatch(addMovie());// 11
store.dispatch(addMovie());// 12
store.dispatch(addMovie());// 13
store.dispatch(addMovie());// 14
store.dispatch(setMovie(10));// 10
store.dispatch(removeMovie());// 9

store.dispatch(addGame());// 21
store.dispatch(addGame());// 22
store.dispatch(addGame());// 23
store.dispatch(addGame());// 24
store.dispatch(setGame(10));// 10
store.dispatch(removeGame());// 9
