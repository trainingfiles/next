import { legacy_createStore } from "redux";
const createStore = legacy_createStore;

// HERO STATE
const ADD_HERO = "ADD_HERO";
const REMOVE_HERO = "REMOVE_HERO";
const SET_HERO = "SET_HERO";

// MOVIE STATE
const ADD_MOVIE = "ADD_MOVIE";
const REMOVE_MOVIE = "REMOVE_MOVIE";
const SET_MOVIE = "SET_MOVIE";

// GAME STATE
const ADD_GAME = "ADD_GAME";
const REMOVE_GAME = "REMOVE_GAME";
const SET_GAME = "SET_GAME";

const addHero = function(){
    return {
                type : ADD_HERO
            }; 
}
const removeHero = function(){
    return {
                type : REMOVE_HERO,
            }; 
}
const setHero = function(count){
    return {
                type : SET_HERO,
                payload : count
            }; 
}
//----------------------------------
const addGame = function(){
    return {
                type : ADD_GAME
            }; 
}
const removeGame = function(){
    return {
                type : REMOVE_GAME,
            }; 
}
const setGame = function(count){
    return {
                type : SET_GAME,
                payload : count
            }; 
}
//-----------------------------------
const addMovie = function(){
    return {
                type : ADD_MOVIE
            }; 
}
const removeMovie = function(){
    return {
                type : REMOVE_MOVIE,
            }; 
}
const setMovie = function(count){
    return {
                type : SET_MOVIE,
                payload : count
            }; 
}

const initialState = {
    herocount : 0,
    moviecount : 10,
    gamecount : 20
}

function reducer(state = initialState, action){
    switch(action.type){
        case ADD_HERO : return { ...state, herocount : state.herocount+1 }
        case REMOVE_HERO : return {...state, herocount : state.herocount-1 }
        case SET_HERO : return { ...state, herocount :  action.payload }
        case ADD_MOVIE : return { ...state, moviecount : state.moviecount+1 }
        case REMOVE_MOVIE : return { ...state, moviecount : state.moviecount-1 }
        case SET_MOVIE : return { ...state, moviecount :  action.payload }
        case ADD_GAME : return { ...state, gamecount : state.gamecount+1 }
        case REMOVE_GAME : return { ...state, gamecount : state.gamecount-1 }
        case SET_GAME : return { ...state, gamecount :  action.payload }
        default : return state
    };
};

const store = createStore(reducer);

console.log(store.getState());

let unsubscribe = store.subscribe(()=>{
    console.log("upon change of the state",store.getState());
});

store.dispatch(addHero());// 1
store.dispatch(addHero());// 2
store.dispatch(addHero());// 3
store.dispatch(addHero());// 4
store.dispatch(setHero(10));// 14
store.dispatch(removeHero());// 13

store.dispatch(addMovie());// 11
store.dispatch(addMovie());// 12
store.dispatch(addMovie());// 13
store.dispatch(addMovie());// 14
store.dispatch(setMovie(10));// 10
store.dispatch(removeMovie());// 9

store.dispatch(addGame());// 21
store.dispatch(addGame());// 22
store.dispatch(addGame());// 23
store.dispatch(addGame());// 24
store.dispatch(setGame(10));// 10
store.dispatch(removeGame());// 9
