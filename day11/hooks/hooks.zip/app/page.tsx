import Hero from "./components/hero";

export default function Home() {
  return <div>
          <h1 className="text-4xl text-center">use Reducer Hook</h1>
          <hr />
          <Hero/>
        </div>  
}
