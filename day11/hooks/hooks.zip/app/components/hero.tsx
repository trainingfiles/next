"use client";
import { useReducer } from "react"

export default function Hero(){
    /*     
    const [firstname, setFirstHero] = useState("");
    const [lastname, setLastHero] = useState(""); 
    */
   // useReducer(reducerFunction,default value);

   const heroReducer = (state, action)=>{
    switch(action.type){
        case "CHANGE_FIRSTNAME" : return {...state, firstname : action.payload}
        case "CHANGE_LASTNAME" : return {...state, lastname : action.payload}
        case "CHANGE_POWER" : return {...state, power : action.payload}
        case "CHANGE_VERSION" : return {...state, version : action.payload}
        default : return state
    }
   };
   // 
   const [store, dispatch] = useReducer(heroReducer,{ 
                                            firstname : "default", 
                                            lastname : "default",
                                            power : 0,
                                            version : 0,
                                        });

    return (
    <div>
        <h2> Hero Component </h2>
        <h3>First Name { store.firstname }</h3>
        <h3>Last Name { store.lastname }</h3>
        <h3>Hero Power { store.power }</h3>
        <h3>Hero Version { store.version }</h3>
        <br />
        <label htmlFor="fname">First Name : </label>
        <input id="fname" className="border-2" 
        onInput={(evt)=>dispatch({type : "CHANGE_FIRSTNAME", payload : evt.target.value})}  />
        <br />
        <label htmlFor="lname">Last Name : </label>
        <input id="lname" className="border-2" 
        onInput={(evt)=>dispatch({type : "CHANGE_LASTNAME", payload : evt.target.value})}  />
        <br />
        <label htmlFor="hpower">Hero Power : </label>
        <input type="range" id="hpower" className="border-2" 
        onInput={(evt)=>dispatch({type : "CHANGE_POWER", payload : evt.target.value})}  />
        <br />
        <label htmlFor="hpower">Hero Version : </label>
        <input type="button" id="hpower" value={"Click to change"}  className="border-2" 
        onClick={(evt)=>dispatch({type : "CHANGE_VERSION", payload : Math.round( Math.random() * 100 )})}  />
    </div>
    )
}