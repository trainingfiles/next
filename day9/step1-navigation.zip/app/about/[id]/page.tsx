export default async function AboutWithParams({ params } : { params : Promise<{ id : string }>}) {
    const param = (await params).id;
  return <div>
            <h1>About Page with Params {param}</h1>
          </div>
}
