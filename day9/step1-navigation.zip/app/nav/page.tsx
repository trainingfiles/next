'use client';

import Link from "next/link"
import { useState } from "react";
import { usePathname } from "next/navigation";

export default function NavComp(){
     const [randNumber, setRandNumber] = useState(0);
     const clickHandler = function(){
        setRandNumber(Math.round(Math.random() * 1000 ));
     };
    const pathName = usePathname();
    console.log(pathName);
    const styleLink = (path:string)=>{
        console.log(pathName.startsWith(path))
        if(pathName === path || (pathName.startsWith(path) && path !== "/")){
            return "text-2xl ml-2 bg-sky-300"
        }else{
            return "text-2xl ml-2"
        }
    }
    return   <div className="navbar bg-base-100 shadow-sm">
                <div className="navbar-start">
                <ul className="menu menu-horizontal px-1">
                    <li>
                        <Link className={styleLink('/')} href="/">Home</Link>
                    </li>
                    <li>
                       <Link className={styleLink('/about/')} href={'/about/'+randNumber}>About Page </Link>
                    </li>
                    <li>
                        <Link className={styleLink('/contact')} href="/contact">Contact Page</Link>
                    </li>
                </ul>
                </div>
                <div className="navbar-end">
                    <button className="btn" onClick={clickHandler}>Click to Change {randNumber}</button>
                </div>
            </div>
}