'use client'
import { useRouter } from "next/navigation"
import { useEffect } from "react";

export default function Home() {
  const router = useRouter();
  useEffect(()=>{
    setTimeout(()=>{
      router.push("/about/25")
    },4000)
  })
  return <div>
            <h1>Home Page</h1>
            <button onClick={()=> router.push("/contact")} className="btn btn-error">Go to Contact Page</button>
          </div>
}
