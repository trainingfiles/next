import mongoose from "mongoose";
import { NextRequest, NextResponse } from "next/server";

// Connection Settings
const connect = function(){
    mongoose.connect(process.env.MONGODB_URL+"")
    .then(res => console.log("DB Connected"))
    .catch(err => console.log("Error", err));
}

// Model
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;
const Hero = mongoose.model("Hero",new Schema({
    id : ObjectId,
    name : String,
    era : String,
    region : String
}));

export async function GET(request:NextRequest){
    connect();
    let heroeslist ; 
    await Hero.find().then(dbres => {
        heroeslist = dbres;
    } );
    return await NextResponse.json(heroeslist)
}

export async function POST(request:NextRequest){
   const newHero = await request.json()
   const hero = await new Hero({
       name : newHero.name,
       era : newHero.era,
       region : newHero.region
   });
   hero.save().then(dbres => console.log(dbres.name, "was added in to database"))
   .catch(err => console.log("Error", err));
   
   return NextResponse.json("post was called")
}