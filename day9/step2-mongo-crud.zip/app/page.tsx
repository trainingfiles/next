'use client'

import { useEffect, useState } from "react"

interface IHero{
  _id : string
  name : string
  era : string
  region : string
}

export default function Home() {
  const [heroes, setHeroes] = useState([]);
  const [newHero, setNewHero] = useState({
    name : "",
    era : "",
    region : ""
  });
  useEffect(()=>{
    fetch("http://localhost:3000/api/heroes")
    .then(res => res.json())
    .then(herores => setHeroes(herores) )
    
  },[]);
  //----------------------------------
  const changeHandler = (evt)=>{
    setNewHero({...newHero, [evt.target.id] : evt.target.value })
  }
  //----------------------------------
  const addNewHero = () => {
    fetch("http://localhost:3000/api/heroes",{
      method : "POST",
      body : JSON.stringify(newHero),
    })
  }
  return <div>
    <h2 className="text-center text-4xl">MongoDB CRUD</h2>
    {/*     
    R : step 1
    C : step 2
    U : step 3
    D : step 4 
    */}

<fieldset className="fieldset m-auto w-80">
  <legend className="fieldset-legend">Add Hero</legend>
  <label htmlFor="name">Hero Name</label>
  <input id="name" type="text" onChange={changeHandler} className="input" value={newHero.name} placeholder="Hero Name" />
  <br />
  <label htmlFor="era">Hero Era</label>
  <input id="era" type="text" onChange={changeHandler} className="input" value={newHero.era} placeholder="Hero Era" />
  <br />
  <label htmlFor="region">Hero Region</label>
  <input id="region" type="text" onChange={changeHandler} className="input" value={newHero.region} placeholder="Hero Region" />
  <button onClick={ addNewHero } className="btn btn-primary">Add Hero</button>
</fieldset>
    <table className="table">
      <thead>
        <tr>
          <th>Sl #</th>
          <th>Name </th>
          <th>Era </th>
          <th>Region</th>
          <th>Edit</th>
          <th>Delete</th>
        </tr>
      </thead>
      <tbody>
        { heroes.map((val:IHero, idx) => <tr key={val._id}>
            <td>{idx+1}</td>
            <td>{ val.name }</td>
            <td>{ val.era }</td>
            <td>{ val.region }</td>
            <td>
              <button className="btn btn-soft btn-primary">Edit</button>
            </td>
            <td>
              <button className="btn btn-soft btn-secondary">Delete</button>
            </td>
        </tr>
      )}
      </tbody>
    </table>
  </div>
}
