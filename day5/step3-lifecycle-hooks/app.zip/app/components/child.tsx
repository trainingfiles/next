import { useEffect } from "react"

export default function ChildComp({ version }){
    { /* 
        mount : is component loaded 
        update : did the component get an update via prop / state
        unmount : was the component unmounted
        */
        }
    // was called when the component was mounted
     
    useEffect(()=>{
        console.log("child component was mounted")
    },[]);
    
    // was called when the component's version was changed
    useEffect(()=>{
        console.log("version was changed to ", version)
    },[version]);
    
    // was called when the component's version was changed
    useEffect(()=>{
        return ()=>{
            console.log("component was unmounted")
    }
    },[]); 
    
    /* useEffect(()=>{
        console.log("child component was mounted / updated")
        return ()=>{
            console.log("component was unmounted")
        }
    },[version]); */
    return <div>
                <h1>Child Component</h1>
                <h2>Version : { version }</h2>
            </div>
}