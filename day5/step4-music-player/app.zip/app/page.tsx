"use client";

import { useState } from "react"
import MusicComp from "./components/audioComp";

export default function Home(){
  let [currentTrack, setCurrentTrack] = useState('');
  let [playlist, setPlayList] = useState([
        {
        id: 1,
        title: "Mindless Attrition",
        artist: "Martin Klem",
        duration: 112, // in seconds
        cover: "001.jpg",
        url: "001 Mindless Attrition.mp3",
        isFavorite: false,
      },
      {
        id: 2,
        title: "No Spark",
        artist: "White Bones",
        duration: 112,
        cover: "002.jpg",
        url: "002 No Spark.mp3",
        isFavorite: true,
      },
      {
        id: 3,
        title: "Common Mistake",
        artist: "Water Mirrors",
        duration: 121,
        cover: "003.jpg",
        url: "003 Common Mistake.mp3",
        isFavorite: false,
      },
      {
        id: 4,
        title: "My Sweet Cabriolet",
        artist: "Edward Joe Myers",
        duration: 125,
        cover: "004.jpg",
        url: "004 My Sweet Cabriolet.mp3",
        isFavorite: false,
      },
      {
        id: 5,
        title: "The Tonight Show",
        artist: "Martin Baekkevold",
        duration: 106,
        cover: "005.jpg",
        url: "005 The Tonight Show.mp3",
        isFavorite: false,
      }
  ]);

  return <div>
          <h1>Music Player</h1>
          <h2>Playing : {currentTrack || "waiting to play..."}</h2>
          {playlist.map((val)=> <MusicComp setCurrentTrack={setCurrentTrack} currentTrack={currentTrack} {...val} key={val.id}/> )}
         </div>
}