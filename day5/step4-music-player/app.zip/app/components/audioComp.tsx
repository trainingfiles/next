import Image from "next/image";
import { Dispatch, SetStateAction, useEffect, useRef, useState } from "react";

interface Props{
    id: number,
    title: string,
    artist: string,
    duration: number, 
    cover: string,
    url: string,
    isFavorite: boolean,
    currentTrack : string,
    setCurrentTrack: Dispatch<SetStateAction<string>>
}

export default function MusicComp(props:Props){
    const audio = useRef(null);
    const log = useRef(null);
    const [isFav, setIsFav] = useState(props.isFavorite)
    useEffect(()=>{
        if(props.currentTrack === props.title){
            audio.current.play();
            setInterval(()=> log.current.textContent = audio.current.currentTime ,10);
        }else{
            audio.current.currentTime = 0;
            audio.current.pause();
        }
    },[props.currentTrack]);
    const playFun = function(){
        props.setCurrentTrack(props.title);
    }
    return <div style={ {display : "flex", fontFamily: "sans-serif", backgroundColor : "silver", width : "400px", height : "100px", margin:"10px", borderRadius : "10px", padding : "10px"} }>
                <Image alt="music poster" loading="eager" style={ {borderRadius : "10px"} } src={"/"+props.cover} width={100} height={100} />
                <div style={ { paddingLeft : "10px"} }>
                    <div style={ { fontWeight : "bold"} }>{ props.title }</div>
                    <hr />
                    <div>{ "By : "+props.artist }</div>
                    <div>{ props.duration+" sec" }</div>
                    <button style={ {color : "red"} } onClick={()=> setIsFav(!isFav)}>{ isFav ? "❤" : "♡" }</button>
                    <audio ref={audio} src={"/"+props.url}></audio>
                    <button onClick={playFun}>Play ► </button>
                    <button onClick={()=> audio.current.pause() }>Pause ⏸︎ </button>
                    &nbsp;
                    &nbsp;
                    <span ref={ log }> </span>
                </div>
           </div>
}
