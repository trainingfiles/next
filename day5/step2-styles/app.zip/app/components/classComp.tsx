import "./classstyle.css";
export default function ClassComp(){
    return <div>
                <h1>Component Class</h1>
                <div className="box">Class Box</div>
            </div>
}