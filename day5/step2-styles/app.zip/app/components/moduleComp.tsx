let mystyle;
async function loadStyle() {
  if (false) {
    mystyle = await import("./mystyle.module.css");
  } else {
    mystyle = await import("./mystylered.module.css");
  }
}
loadStyle();

export default function ModuleComp() {
  return (
    <div>
      <h1>Module Style</h1>
      <div className={mystyle.box}>Class Box</div>
    </div>
  );
}
