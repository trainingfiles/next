import boxStyle from "../boxStyle";
export default function StyleComp(){
      const extBox = boxStyle;
    return <div>
        <h1>Component Styles</h1>
          {/* 
            
            inline style 
            infile style
            external style
            app / global style
            style modules
          */}
          <div style={ { ...extBox } }>
            I am a box
          </div>
          <div style={ { ...extBox, "backgroundColor" : "orange", "fontSize" : "24px" } }>
            I am a box
          </div>
          <div style={ { ...extBox, "backgroundColor" : "darkseagreen" } }>
            I am a box
          </div>
    </div>
}