import ClassComp from "./components/classComp";
import ModuleComp from "./components/moduleComp";
import StyleComp from "./components/stylecomp";

export default function Home(){

  return <div>
          <StyleComp/>
          <hr />
          <ClassComp/>
          <hr />
          <ModuleComp/>
        </div>
}
