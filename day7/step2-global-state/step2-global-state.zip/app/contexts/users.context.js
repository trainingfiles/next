import React from "react";
const UsersContext = React.createContext([]);
/* 
UsersContext.Consumer
UsersContext.Provider
UsersContext.displayName 
*/
export {UsersContext};