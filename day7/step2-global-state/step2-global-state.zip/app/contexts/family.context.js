import React from "react";

const FamilyContext = React.createContext("");

/* 
owner of the state
FamilyContext.Provider 
user of the state
FamilyContext.Consumer
*/
export {FamilyContext}