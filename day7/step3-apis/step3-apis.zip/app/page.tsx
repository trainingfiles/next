export default function Home(){
  fetch("/api/data").then(dbres => dbres.json()).then(res => console.log(res));
  return <div>
    <h2>First API Ex</h2>
  </div>
}