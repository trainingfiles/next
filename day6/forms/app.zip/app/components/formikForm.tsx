'use client'
import { useFormik } from "formik";

/* 
manage form state
validation
form submission
*/
export default function FormikForm(){
    const inputStyle = {
        width : "100px", 
        display : "inline-block",
        padding : "5px", 
        margin : "5px",
        textAlign : "right"
    };
    const errorStyle = {
        paddingLeft : "100px", 
        color : "crimson", 
        fontSize : "14px"
    }
    const formik = useFormik({
            initialValues : {
                uName : "",
                ueMail : "",
                uAge : "",
                uCity : "",
            },
            validate : values => {
                const errors = {};
                if (!values.uName) {
                    errors.uName = 'Name is Required';
                } else if (values.uName.length > 20) {
                    errors.uName = 'Must be 15 characters or less';
                }
                if (!values.ueMail) {
                    errors.ueMail = 'eMail is Required';
                } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.ueMail)) {
                    errors.ueMail = 'Invalid email address';
                }
                if (!values.uAge) {
                    errors.uAge = 'Age is Required';
                } else if (values.uAge < 18) {
                    errors.uAge = 'You are too young to join us';
                } else if (values.uAge > 90) {
                    errors.uAge = 'You are too old to join us';
                }
                if (!values.uCity) {
                    errors.uCity = 'City is Required';
                }
                return errors;
            },
            onSubmit : (evt) =>{
                // if(!formik.isValid){
                //     // 
                // }else{

                // }
            }
    });
    return <div style={ { margin : "auto", backgroundColor : "silver", fontFamily : "sans-serif", padding : "10px", width : "400px", border : "1px solid gray", borderRadius : "10px"} }>
          <h1 style={ { margin : "0px ", textAlign : "center", color : "white"} }>Formik in NextJS</h1>
          <hr />
          <div>
              <form action="#" method="get" onSubmit={formik.handleSubmit} >
                <div>
                  <label style={inputStyle} htmlFor="uName">Name : </label>
                  <input name="uName" value={formik.values.uName} onChange={formik.handleChange} id="uName"/>
                  {formik.errors.uName && <div style={ errorStyle }>{formik.errors.uName}</div>}
                </div>
                <div>
                  <label style={inputStyle} htmlFor="ueMail">eMail : </label>
                  <input name="ueMail" value={formik.values.ueMail} onChange={formik.handleChange} id="ueMail" type="email"  />
                  {formik.errors.ueMail && <div style={ errorStyle }>{formik.errors.ueMail}</div>}
                </div>
                <div>
                  <label style={inputStyle} htmlFor="uAge">Age : </label>
                  <input name="uAge" value={formik.values.uAge} onChange={formik.handleChange} id="uAge" type="text"  />
                  {formik.errors.uAge && <div style={ errorStyle }>{formik.errors.uAge}</div>}
                </div>
                <div>
                  <label style={inputStyle} htmlFor="uCity">City : </label>
                  <input name="uCity" value={formik.values.uCity} onChange={formik.handleChange} id="uCity"/>
                  {formik.errors.uCity && <div style={ errorStyle }>{formik.errors.uCity}</div>}
                </div>
                <div>
                  <label style={inputStyle}></label>
                  <button type="submit" style={ {padding : "5px"} } >Submit</button>
                </div>
              </form>
              {/* <p>{JSON.stringify(formik.values)}</p> */}
          </div>
        </div>
}