'use client'
import { useRef, useState } from "react";

export default function NextForm(){
    
  const formElement = useRef(null);

  const inputStyle = {
    width : "100px", 
    display : "inline-block",
    padding : "5px", 
    margin : "5px",
    textAlign : "right"
  };
  const [userInfo, setUserInfo] = useState({
    uName : "",
    ueMail : "",
    uAge : '',
    uCity : "",
  });
  const [infoError, setUserInfoError] = useState({
    uNameError : "",
    ueMailError : "",
    uAgeError : "",
    uCityError : "",
  });

  /*   
  const nameChangeHandler = (evt)=>{
    setUserInfo({...userInfo, uName : evt.target.value})
  }
  const emailChangeHandler = (evt)=>{
    setUserInfo({...userInfo, ueMail : evt.target.value})
  }
  const ageChangeHandler = (evt)=>{
    setUserInfo({...userInfo, uAge : evt.target.value})
  }
  const cityChangeHandler = (evt)=>{
    setUserInfo({...userInfo, uCity : evt.target.value})
  } 
  */
  const changeHandler = (evt)=>{
    if(evt.target.id === "uAge"){
      setUserInfo({...userInfo, [evt.target.id] : Number(evt.target.value) });
    }else{
      setUserInfo({...userInfo, [evt.target.id] : evt.target.value });
    }
  };

  const submitHandler = (evt) => {
    evt.preventDefault();
    // console.log(JSON.stringify(userInfo));
    if(!userInfo.uName){ 
      setUserInfoError({...infoError, uNameError : "User Name is Required"}) 
    }
    else if(!userInfo.ueMail){ 
      setUserInfoError({...infoError, ueMailError : "User eMail is Required"}) 
    }
    else if(!userInfo.uAge){  
      setUserInfoError({...infoError, uAgeError : "User Age is Required"}) 
    }
    else if(!userInfo.uCity){ 
      setUserInfoError({...infoError, uCityError : "User City is Required"})  
    }else{
      if(userInfo.uAge < 18){
         console.log("age less than 18")
         setUserInfoError({uNameError : "",ueMailError : "",uCityError : "", uAgeError : "You are too young to join us"}) 
      }else if(userInfo.uAge > 90){
         console.log("age more than 90")
         setUserInfoError({uNameError : "",ueMailError : "",uCityError : "", uAgeError : "You are too old to join us"}) 
      }else{

       setUserInfoError({
                          uNameError : "",
                          ueMailError : "",
                          uAgeError : "",
                          uCityError : "",
                        }) ;
        formElement.current.submit();
      }
    }
  }
    return <div style={ { margin : "auto", backgroundColor : "silver", fontFamily : "sans-serif", padding : "10px", width : "400px", border : "1px solid gray", borderRadius : "10px"} }>
          <h1 style={ { margin : "0px ", textAlign : "center", color : "white"} }>Forms in NextJS</h1>
          <hr />
          <div>
              <form ref={formElement} action="#" method="get" onSubmit={submitHandler}>
                <div>
                  <label style={inputStyle} htmlFor="uName">Name : </label>
                  <input value={userInfo.uName} onChange={changeHandler} name="uName" id="uName"/>
                  {infoError.uNameError && <div style={ {paddingLeft : "100px", color : "crimson", fontSize : "14px"} }>{infoError.uNameError}</div>}
                </div>
                <div>
                  <label style={inputStyle} htmlFor="ueMail">eMail : </label>
                  <input value={userInfo.ueMail} onChange={changeHandler} name="ueMail" id="ueMail" type="email"  />
                  {infoError.ueMailError && <div style={ {paddingLeft : "100px", color : "crimson", fontSize : "14px"} }>{infoError.ueMailError}</div>}
                </div>
                <div>
                  <label style={inputStyle} htmlFor="uAge">Age : </label>
                  <input value={userInfo.uAge} onChange={changeHandler} name="uAge" id="uAge" type="text"  />
                  {infoError.uAgeError && <div style={ {paddingLeft : "100px", color : "crimson", fontSize : "14px"} }>{infoError.uAgeError}</div>}
                </div>
                <div>
                  <label style={inputStyle} htmlFor="uCity">City : </label>
                  <input value={userInfo.uCity} onChange={changeHandler} name="uCity" id="uCity"/>
                  { infoError.uCityError && <div style={ {paddingLeft : "100px", color : "crimson", fontSize : "14px"} }>{infoError.uCityError}</div>}
                </div>
                <div>
                  <label style={inputStyle}></label>
                  <button type="submit" style={ {padding : "5px"} } >Submit</button>
                </div>
              </form>
          </div>
        </div>
}