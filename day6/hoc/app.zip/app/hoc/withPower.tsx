import { ElementType, useState } from "react";

export default function WithPower(OriginalComponent:ElementType){
    const Wrapper = (props) => {
        const [power, setPower] = useState(0);
        const increasePower = () => {
            setPower(power+1);
        }
        return <OriginalComponent {...props} power={power} increasePower={ increasePower } />
    }
    return Wrapper;
}